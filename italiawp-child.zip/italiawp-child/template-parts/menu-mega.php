<nav class="Megamenu Megamenu--default js-megamenu">
    <?php wp_nav_menu( array( 'theme_location' => 'h-menu', 'menu_id' => 'primary-menu', 'menu_class' => 'Megamenu-list', 'fallback_cb' => false, 'depth' => 1 ) ); ?>
</nav>