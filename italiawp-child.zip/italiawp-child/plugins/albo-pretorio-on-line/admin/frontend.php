<?php
/**
 * Gestione FrontEnd.
 * @link       http://www.eduva.org
 * @since      4.2
 *
 * @package    ALbo On Line
 */

if(preg_match('#' . basename(__FILE__) . '#', $_SERVER['PHP_SELF'])) { die('You are not allowed to call this page directly.'); }

ob_start();

if (isset($_REQUEST['id']) And !is_numeric($_REQUEST['id'])) {
	$_REQUEST['id']=0;
	echo "<br />".sprintf(__("%sATTENZIONE.%s E' stato indicato un VALORE non valido per il parametro %s","albo-online"),'<span style="color:red;">',"</span>",'<span style="color:red;">ID</span>');
	return;
}
if (isset($_REQUEST['action']) And $_REQUEST['action']!=wp_strip_all_tags($_REQUEST['action'])) {
	unset($_REQUEST['action']);
	echo "<br />".sprintf(__("%sATTENZIONE.%s E' stato indicato un VALORE non valido per il parametro %s","albo-online"),'<span style="color:red;">',"</span>",'<span style="color:red;">Action</span>');
	return;
}
if (isset($_REQUEST['categoria']) And !is_numeric($_REQUEST['categoria'])) {
	$_REQUEST['categoria']=0;
	echo "<br />".sprintf(__("%sATTENZIONE.%s E' stato indicato un VALORE non valido per il parametro %s","albo-online"),'<span style="color:red;">',"</span>",'<span style="color:red;">Categoria</span>');
}
if (isset($_REQUEST['numero']) And $_REQUEST['numero']!="" AND !is_numeric($_REQUEST['numero'])) {
	$_REQUEST['numero']="";
	echo "<br />".sprintf(__("%sATTENZIONE.%s E' stato indicato un VALORE non valido per il parametro %s","albo-online"),'<span style="color:red;">',"</span>",'<span style="color:red;">Numero</span>');
}
if (isset($_REQUEST['anno']) And !is_numeric($_REQUEST['anno'])) {
	$_REQUEST['anno']=0;
	echo "<br />".sprintf(__("%sATTENZIONE.%s E' stato indicato un VALORE non valido per il parametro %s","albo-online"),'<span style="color:red;">',"</span>",'<span style="color:red;">Anno</span>');
}
if (isset($_REQUEST['ente']) And !is_numeric($_REQUEST['ente'])) {
	$_REQUEST['ente']="-1";
	echo "<br />".sprintf(__("%sATTENZIONE.%s E' stato indicato un VALORE non valido per il parametro %s","albo-online"),'<span style="color:red;">',"</span>",'<span style="color:red;">Ente</span>');
}
if (isset($_REQUEST['Pag']) And !is_numeric($_REQUEST['Pag'])) {
	$_REQUEST['Pag']=1;
	echo "<br />".sprintf(__("%sATTENZIONE.%s E' stato indicato un VALORE non valido per il parametro %s","albo-online"),'<span style="color:red;">',"</span>",'<span style="color:red;">Pag</span>');
}
if (isset($_REQUEST['oggetto']) And $_REQUEST['oggetto']!=wp_strip_all_tags($_REQUEST['oggetto'])) {
	$_REQUEST['oggetto']="";
	echo "<br />".sprintf(__("%sATTENZIONE.%s E' stato indicato un VALORE non valido per il parametro %s","albo-online"),'<span style="color:red;">',"</span>",'<span style="color:red;">Oggetto</span>');
}
if (isset($_REQUEST['riferimento']) And $_REQUEST['riferimento']!=wp_strip_all_tags($_REQUEST['riferimento'])) {
	$_REQUEST['riferimento']="";
	echo "<br />".sprintf(__("%sATTENZIONE.%s E' stato indicato un VALORE non valido per il parametro %s","albo-online"),'<span style="color:red;">',"</span>",'<span style="color:red;">Riferimento</span>');
}
if (isset($_REQUEST['DataInizio']) And $_REQUEST['DataInizio']!=wp_strip_all_tags($_REQUEST['DataInizio'])) {
	$_REQUEST['DataInizio']="";
	echo "<br />".sprintf(__("%sATTENZIONE.%s E' stato indicato un VALORE non valido per il parametro %s","albo-online"),'<span style="color:red;">',"</span>",'<span style="color:red;">Da Data</span>');
}
if (isset($_REQUEST['DataFine']) And $_REQUEST['DataFine']!=wp_strip_all_tags($_REQUEST['DataFine'])) {
	$_REQUEST['DataFine']="";
	echo "<br />".sprintf(__("%sATTENZIONE.%s E' stato indicato un VALORE non valido per il parametro %s","albo-online"),'<span style="color:red;">',"</span>",'<span style="color:red;">A Data</span>');
}
if (isset($_REQUEST['filtra']) And ($_REQUEST['filtra']!=__("Filtra","albo-online") And $_REQUEST['filtra']!=__("Annulla Filtro","albo-online"))) {
	$_REQUEST['filtra']='.__("Filtra","albo-online").';
	echo "<br />".sprintf(__("%sATTENZIONE.%s E' stato indicato un VALORE non valido per il parametro %s","albo-online"),'<span style="color:red;">',"</span>",'<span style="color:red;">filtra</span>');
}
if (isset($_REQUEST['vf']) And ($_REQUEST['vf']!="s" And $_REQUEST['vf']!="h" And $_REQUEST['vf']!="undefined")) {
	$_REQUEST['vf']="undefined";
	echo "<br />".sprintf(__("%sATTENZIONE.%s E' stato indicato un VALORE non valido per il parametro %s","albo-online"),'<span style="color:red;">',"</span>",'<span style="color:red;">vf</span>');
}
foreach ($_REQUEST as $Key => $Val) {
	$_REQUEST[$Key]=htmlspecialchars(wp_strip_all_tags($_REQUEST[$Key]));
}

include_once(dirname (__FILE__) .'/frontend_filtro.php');

if (isset($_REQUEST['action'])) {
	switch ($_REQUEST['action']) {
		case 'printatto':
			if (is_numeric($_REQUEST['id'])) {
				if ($_REQUEST['pdf'] == 'c') {
					StampaAtto($_REQUEST['id'], 'c');
				} elseif ($_REQUEST['pdf'] == 'a') {
					StampaAtto($_REQUEST['id'], 'a');
				}
			} else {
				echo sprintf(__("ATTENZIONE:%sE' stato indicato un parametro non valido che può rappresentare un ATTACCO INFORMATICO AL SITO","albo-online"),"<br />");
			}
			break;
		case 'visatto':
			if (is_numeric($_REQUEST['id']))
				$ret=VisualizzaAtto($_REQUEST['id']);
			else {
				echo sprintf(__("ATTENZIONE:%sE' stato indicato un parametro non valido che può rappresentare un ATTACCO INFORMATICO AL SITO","albo-online"),"<br />");
			}
			break;
		case 'addstatall':
			if (is_numeric($_GET['id']) and is_numeric($_GET['idAtto']))
				ap_insert_log(5,5,(int)$_GET['id'],"Visualizzazione",(int)$_GET['idAtto']);
			break;
		default:
			if (isset($_REQUEST['filtra'])) {
				if (!is_numeric($_REQUEST['categoria']) OR
				!is_numeric($_REQUEST['numero']) OR
				!is_numeric($_REQUEST['anno']) OR
				!is_numeric($_REQUEST['ente'])) {
					echo sprintf(__("ATTENZIONE:%sE' stato indicato un parametro non valido che può rappresentare un ATTACCO INFORMATICO AL SITO","albo-online"),"<br />");
					break;
				}
				if ($_REQUEST['oggetto']!=wp_strip_all_tags($_REQUEST['oggetto'])) {
					echo sprintf(__("ATTENZIONE:%sE' stato indicato un parametro non valido che può rappresentare un ATTACCO INFORMATICO AL SITO","albo-online"),"<br />");
					break;
				}
				if ($_REQUEST['riferimento']!=wp_strip_all_tags($_REQUEST['riferimento'])) {
					echo sprintf(__("ATTENZIONE:%sE' stato indicato un parametro non valido che può rappresentare un ATTACCO INFORMATICO AL SITO","albo-online"),"<br />");
					break;
				}
				$ret=Lista_Atti($Parametri,$_REQUEST['categoria'],(int)$_REQUEST['numero'],(int)$_REQUEST['anno'], htmlentities($_REQUEST['oggetto']),htmlentities($_REQUEST['DataInizio']),htmlentities($_REQUEST['DataFine']), htmlentities($_REQUEST['riferimento']),$_REQUEST['ente']);
			} else if (isset($_REQUEST['annullafiltro'])) {
				unset($_REQUEST['categoria']);
				unset($_REQUEST['numero']);
				unset($_REQUEST['anno']);
				unset($_REQUEST['oggetto']);
				unset($_REQUEST['riferimento']);
				unset($_REQUEST['DataInizio']);
				unset($_REQUEST['DataFine']);
				unset($_REQUEST['ente']);
				$ret=Lista_Atti($Parametri);
			} else {
				$ret=Lista_Atti($Parametri);
			}
	}
} else {
	if (isset($_REQUEST['filtra'])) {
		if ((isset($_REQUEST['categoria']) And !is_numeric($_REQUEST['categoria'])) OR
		(isset($_REQUEST['numero']) And $_REQUEST['numero']!="" AND !is_numeric($_REQUEST['numero'])) OR
		(isset($_REQUEST['anno']) And !is_numeric($_REQUEST['anno'])) OR
		(isset($_REQUEST['ente']) And !is_numeric($_REQUEST['ente']))) {
			echo sprintf(__("ATTENZIONE:%sE' stato indicato un parametro non valido che può rappresentare un ATTACCO INFORMATICO AL SITO","albo-online"),"<br />");
			return;
		}
		if ($_REQUEST['oggetto']!=wp_strip_all_tags($_REQUEST['oggetto'])) {
			echo sprintf(__("ATTENZIONE:%sE' stato indicato un parametro non valido che può rappresentare un ATTACCO INFORMATICO AL SITO","albo-online"),"<br />");
			return;
		}
		if ($_REQUEST['riferimento']!=wp_strip_all_tags($_REQUEST['riferimento'])) {
			echo sprintf(__("ATTENZIONE:%sE' stato indicato un parametro non valido che può rappresentare un ATTACCO INFORMATICO AL SITO","albo-online"),"<br />");
			return;
		}
		$ret=Lista_Atti($Parametri,(int)$_REQUEST['categoria'],(int)$_REQUEST['numero'],(int)$_REQUEST['anno'], htmlentities($_REQUEST['oggetto']),htmlentities($_REQUEST['DataInizio']),htmlentities($_REQUEST['DataFine']), htmlentities($_REQUEST['riferimento']),(int)$_REQUEST['ente']);
	} else if (isset($_REQUEST['annullafiltro'])) {
		unset($_REQUEST['categoria']);
		unset($_REQUEST['numero']);
		unset($_REQUEST['anno']);
		unset($_REQUEST['oggetto']);
		unset($_REQUEST['riferimento']);
		unset($_REQUEST['DataInizio']);
		unset($_REQUEST['ente']);
		$ret=Lista_Atti($Parametri);
	} else {
		$ret=Lista_Atti($Parametri);

	}
}

function VisualizzaAtto($id){
	$risultato=ap_get_atto($id);
	$risultato=$risultato[0];
	$risultatocategoria=ap_get_categoria($risultato->IdCategoria);
	$risultatocategoria=$risultatocategoria[0];
	$Unitao=ap_get_unitaorganizzativa($risultato->IdUnitaOrganizzativa);
	if ($Unitao!==FALSE)
		$UnitaoNome=$Unitao->Nome;
	else
		$UnitaoNome="";
	$NomeResp=ap_get_responsabile($risultato->RespProc);
	if (count($NomeResp)>0) {
		$NomeResp=$NomeResp[0];
		$NomeResp=stripslashes($NomeResp->Nome." ".$NomeResp->Cognome);
	} else
		$NomeResp="";
	ap_insert_log(5,5,$id,"Visualizzazione");
	$coloreAnnullati=get_option('opt_AP_ColoreAnnullati');
	if ($risultato->DataAnnullamento!='0000-00-00')
		$Annullato='<p style="background-color: '.$coloreAnnullati.';text-align:center;font-size:1.5em;">'.sprintf(__('Atto Annullato dal Responsabile del Procedimento %s Motivo: %s','albo-online'),'<br /><br />','<span style="font-size:1;font-style: italic;">'.stripslashes($risultato->MotivoAnnullamento).'</span>').'</p>';
	else
		$Annullato='';
?>
<section  id="DatiAtto">
	<div class="container clearfix">
		<button class="Button Button--info Button--shadow u-text-r-xs u-margin-bottom-m" onclick="window.location.href='<?php echo $_SERVER['HTTP_REFERER']; ?>'">
		<span class="fas fa-arrow-circle-left"></span> <?php _e("Torna alla Lista","albo-online");?></button>
		<h2><?php _e("Dati atto","albo-online");?></h2>
		<?php echo ($Annullato?"<h3>'.$Annullato.'</h3>":"");?>
		<div class="u-layout-wide u-layoutCenter u-layout-withGutter u-background-white">
				<div class="Grid Grid--withGutter u-padding-all-xs u-text-r-xxs u-margin-r-right">
					<div class="Grid-cell u-sizeFull u-size1of1 u-lg-size8of12 ">
						<table class="table table-striped table-hove">
						    <tbody id="dati-atto">
							<tr>
								<th class="d-w25 text-right" style="border-top:0;"><?php _e("Ente titolare dell'Atto","albo-online");?></th>
								<td class="align-middle"><?php echo stripslashes(ap_get_ente($risultato->Ente)->Nome);?></td>
							</tr>
							<tr>
								<th class="d-w25 text-right"><?php _e("Numero Albo","albo-online"); ?></th>
								<td class="align-middle"><?php echo $risultato->Numero."/".$risultato->Anno;?></td>
							</tr>
							<tr>
								<th class="d-w25 text-right"><?php _e("Codice di Riferimento","albo-online"); ?></th>
								<td class="align-middle"><?php echo stripslashes($risultato->Riferimento);?></td>
							</tr>
							<tr>
								<th class="d-w25 text-right"><?php _e("Oggetto","albo-online");?></th>
								<td class="align-middle"><?php echo stripslashes($risultato->Oggetto);?></td>
							</tr>
							<tr>
							<th class="d-w25 text-right"><?php _e("Data di registrazione","albo-online"); ?></th>
								<td class="align-middle"><?php echo ap_VisualizzaData($risultato->Data);?></td>
							</tr>
							<tr>
							<th class="d-w25 text-right"><?php _e("Data inizio Pubblicazione","albo-online"); ?></th>
							<td class="align-middle"><?php echo ap_VisualizzaData($risultato->DataInizio); ?></td>
							</tr>
							<tr>
								<th class="d-w25 text-right"><?php _e("Data fine Pubblicazione","albo-online"); ?></th>
								<td class="align-middle"><?php echo ap_VisualizzaData($risultato->DataFine)?></td>
							</tr>
							<tr>
								<th class="d-w25 text-right"><?php _e("Data oblio","albo-online"); ?></th>
								<td class="align-middle"><?php echo ap_VisualizzaData($risultato->DataOblio);?></td>
							</tr>
							<tr>
								<th class="d-w25 text-right"><?php _e("Richiedente","albo-online"); ?></th>
								<td class="align-middle"><?php echo stripslashes($risultato->Richiedente); ?></td>
							</tr>							
							<tr>
								<th class="d-w25 text-right"><?php _e("Unità Organizzativa Responsabile","albo-online"); ?></th>
								<td class="align-middle"><?php echo stripslashes($UnitaoNome); ?></td>
							</tr>
							<tr>
								<th class="d-w25 text-right"><?php _e("Responsabile del procedimento amministrativo","albo-online"); ?></th>
								<td class="align-middle"><?php echo $NomeResp; ?></td>
							</tr>							
							<tr>
								<th class="d-w25 text-right"><?php _e("Categoria","albo-online"); ?></th>
								<td class="align-middle"><?php echo stripslashes($risultatocategoria->Nome)?></td>
							</tr>							
<?php
$MetaDati=ap_get_meta_atto($id);
if($MetaDati!==FALSE){
	$Meta="";
	foreach($MetaDati as $Metadato){
		$Meta.="{".$Metadato->Meta."=".$Metadato->Value."} - ";
	}
	$Meta=substr($Meta,0,-3);?>
							<tr>
								<th><?php _e("Meta Dati","albo-online"); ?></th>
								<td style="vertical-align: middle;"><?php echo $Meta;?></td>
							</tr>							
							<tr>
								<th class="d-w25 text-right"><?php _e("Note","albo-online"); ?></th>
								<td class="align-middle"><?php echo stripslashes($risultato->Informazioni);?></td>
							</tr>
<?php }?>
				 	    </tbody>
					</table>
				</div>
				<div class="Grid-cell u-sizeFull u-size1of1 u-lg-size4of12 ">
<?php 
$Soggetti=unserialize($risultato->Soggetti);
$Ruolo="";
if($Soggetti){
	$Soggetti=ap_get_alcuni_soggetti_ruolo(implode(",",$Soggetti));				
	echo "      <h2 class=\"u-padding-bottom-xxl\">".__("Soggetti","albo-online")."</h2>";
} else {
	$Soggetti=array();
}
	foreach ($Soggetti as $Soggetto) {
	if(ap_get_Funzione_Responsabile($Soggetto->Funzione,"Display")=="No"){
		continue;
	}
	if ($Soggetto->Funzione!=$Ruolo) {
		$Ruolo=$Soggetto->Funzione;?>
				<div class="Callout Callout--could u-text-r-xs">
	  				<h4 class="Callout-title"><?php echo ap_get_Funzione_Responsabile($Soggetto->Funzione,"Descrizione"); ?></h4>
	 				<div>
		<?php echo $Soggetto->Cognome." ".$Soggetto->Nome;?><br />
<?php	} 
		if ($Soggetto->Email)
			echo''.__("Email","albo-online").' <a href="mailto:'.$Soggetto->Email.'">'.$Soggetto->Email.'</a><br />';
		if ($Soggetto->Telefono)
			echo	_("Telefono","albo-online")." ".$Soggetto->Telefono."<br />";
		if ($Soggetto->Orario)
			echo 	__("Orario ricevimento","albo-online")." ".$Soggetto->Orario.'<br />';
		if ($Soggetto->Note)
			echo	__("Note","albo-online")." ".$Soggetto->Note;
?>
						</div>
					</div>
<?php }?>
				</div>
			</div>
		</div>
	   	<div>
<?php
$TipidiFiles=ap_get_tipidifiles();
if (strpos(get_permalink(),"?")>0)
	$sep="&amp;";
else
	$sep="?";
$documenti=ap_get_documenti_atto($id);
if (count($documenti)>0) {
	echo '
<h2>'. __("Documenti firmati","albo-online").'</h2>
<div class="Grid Grid--withGutter u-padding-all-l">';
	//print_r($_SERVER);
	foreach ($documenti as $allegato) {
		$Estensione=ap_ExtensionType($allegato->Allegato);
		echo'
<div class="Grid-cell HeadAllegati">
	<div class="u-margin-bottom-xs u-borderRadius-m u-padding-all-m u-border-all-xxs">
		<img src="'.$TipidiFiles[strtolower($Estensione)]['Icona'].'" alt="'.$TipidiFiles[strtolower($Estensione)]['Descrizione'].'" height="30" width="30"allegato/> '.($allegato->DocIntegrale!="1"?'<span class="evidenziato">'.__("Pubblicato per Estratto","albo-online")."</span><br />":"").'<strong>'.__("Descrizione","albo-online").'</strong>: '.strip_tags(($allegato->TitoloAllegato?$allegato->TitoloAllegato:basename( $allegato->Allegato))).'</strong><br /><strong>'.__("Impronta","albo-online").'</strong>: '.$allegato->Impronta.'<br /><strong>'.__("Dimensione file","albo-online").'</strong>: '.ap_Formato_Dimensione_File(is_file($allegato->Allegato)?filesize($allegato->Allegato):0)."<br /><br />";
		if (is_file($allegato->Allegato))
			echo '<a href="'.ap_DaPath_a_URL($allegato->Allegato).'" class="addstatdw noUnderLine" rel="'.get_permalink().$sep.'action=addstatall&amp;id='.$allegato->IdAllegato.'&amp;idAtto='.$id.'" title="'.__("Visualizza Allegato","albo-online").'" target="_blank"><span class="u-text-r-l Icon Icon-zoom-in"></span></a> '.htmlspecialchars_decode($TipidiFiles[strtolower($Estensione)]['Verifica']).' <a href="'.get_permalink().$sep.'action=dwnalle&amp;id='.$allegato->IdAllegato.'&amp;idAtto='.$id.'" class="noUnderLine" title="'.__("Scarica allegato","albo-online").'"><span class="u-text-r-l Icon Icon-download"></span></a>';
		else
			echo basename( $allegato->Allegato).' '.__("File non trovato, il file è stato cancellato o spostato!","albo-online");
		echo '</div>
</div>
';
	}
	echo '</div>';
}
$allegati=ap_get_allegati_atto($id);
if (count($allegati)>0) {
	echo '<h2>'. __("Allegati","albo-online").'</h2>
	<div class="Grid Grid--withGutter u-padding-all-l">';
	foreach ($allegati as $allegato) {
		$Estensione=ap_ExtensionType($allegato->Allegato);
		echo'<div class="Grid-cell HeadAllegati">
	<div class="u-margin-bottom-xs u-borderRadius-m u-padding-all-m u-border-all-xxs">
		<img src="'.$TipidiFiles[strtolower($Estensione)]['Icona'].'" alt="'.$TipidiFiles[strtolower($Estensione)]['Descrizione'].'" height="30" width="30"allegato/> '.($allegato->DocIntegrale!="1"?'<span class="evidenziato">'.__("Pubblicato per Estratto","albo-online")."</span><br />":"").'<strong>'.__("Descrizione","albo-online").'</strong>: '.strip_tags(($allegato->TitoloAllegato?$allegato->TitoloAllegato:basename( $allegato->Allegato))).'</strong><br /><strong>'.__("Impronta","albo-online").'</strong>: '.$allegato->Impronta.'<br /><strong>'.__("Dimensione file","albo-online").'</strong>: '.ap_Formato_Dimensione_File(is_file($allegato->Allegato)?filesize($allegato->Allegato):0)."<br /><br />";
		if (is_file($allegato->Allegato))
			echo '<a href="'.ap_DaPath_a_URL($allegato->Allegato).'" class="addstatdw noUnderLine" rel="'.get_permalink().$sep.'action=addstatall&amp;id='.$allegato->IdAllegato.'&amp;idAtto='.$id.'" title="'.__("Visualizza Allegato","albo-online").'" target="_blank"><span class="u-text-r-l Icon Icon-zoom-in"></span></a> '.htmlspecialchars_decode($TipidiFiles[strtolower($Estensione)]['Verifica']).' <a href="'.get_permalink().$sep.'action=dwnalle&amp;id='.$allegato->IdAllegato.'&amp;idAtto='.$id.'" class="noUnderLine" title="'.__("Scarica allegato","albo-online").'"><span class="u-text-r-l Icon Icon-download"></span></a>';
		else
			echo basename( $allegato->Allegato).' '.__("File non trovato, il file è stato cancellato o spostato!","albo-online");
		echo '</div>
	</div>';
}
echo '</div>
<div class="Prose Alert Alert--info Alert--withIcon" role="alert">
    <h3 class="u-text-h3">'.__("Informazioni","albo-online").'</h3>
    <p class="u-text-p">'.__("L'impronta dei files è calcolata con algoritmo SHA256 al momento dell'upload","albo-online").'</p>
</div>';
	}?>
		</div>
	</div>
</section>
<?php
}

function Lista_Atti($Parametri,$Categoria=0,$Numero=0,$Anno=0,$Oggetto='',$Dadata=0,$Adata=0,$Riferimento='',$Ente=-1){
	switch ($Parametri['stato']){
			case 0:
				$TitoloAtti="Tutti gli Atti";
				break;
			case 1:
				$TitoloAtti="Atti in corso di Validit&agrave;";
				break;
			case 2:
				$TitoloAtti="Atti Scaduti";
				break;
			case 3:
				$TitoloAtti="Atti da Pubblicare";
				break;
	}
	if (isset($Parametri['per_page'])){
		$N_A_pp=$Parametri['per_page'];	
	}else{
		$N_A_pp=10;
	}
	if (isset($Parametri['cat']) and $Parametri['cat']!=0){
		$DesCategorie="";
		$Categoria="";
		$Categorie=explode(",",$Parametri['cat']);
		foreach($Categorie as $Cate){
			$DesCat=ap_get_categoria($Cate);
			$DesCategorie.=$DesCat[0]->Nome.",";
			$Categoria.=$Cate.",";
		}
		$DesCategorie= substr($DesCategorie,0, strlen($DesCategorie)-1);
		$TitoloAtti.=" Categorie ".$DesCategorie;
		$Categoria=substr($Categoria,0, strlen($Categoria)-1);
		$cat=1;
	}else{
		$Categorie=$Categoria;
		$cat=0;
	}
	if (!isset($_REQUEST['Pag'])){
		$Da=0;
		$A=$N_A_pp;
	}else{
		$Da=($_REQUEST['Pag']-1)*$N_A_pp;
		$A=$N_A_pp;
	}
	if (!isset($_REQUEST['ente'])){
         $Ente = '-1';
	}else{
        $Ente = $_REQUEST['ente'];
	}
	$TotAtti=ap_get_all_atti($Parametri['stato'],$Numero,$Anno,$Categorie,$Oggetto,$Dadata,$Adata,'',0,0,true,false,$Riferimento,$Ente);
	$lista=ap_get_all_atti($Parametri['stato'],$Numero,$Anno,$Categorie,$Oggetto,$Dadata,$Adata,'Anno DESC,Numero DESC',$Da,$A,false,false,$Riferimento,$Ente); 
	$titEnte=get_option('opt_AP_LivelloTitoloEnte');
	if ($titEnte=='')
		$titEnte="h2";
	$titPagina=get_option('opt_AP_LivelloTitoloPagina');
	if ($titPagina=='')
		$titPagina="h3";
	$coloreAnnullati=get_option('opt_AP_ColoreAnnullati');
	$colorePari=get_option('opt_AP_ColorePari');
	$coloreDispari=get_option('opt_AP_ColoreDispari');?>
<section  id="FiltroAtti">
	<div class="u-layout-medium u-layoutCenter">
		<h2>Filtri</h2>
		<div class="u-layout-wide u-layoutCenter u-layout-withGutter u-background-white">
				<div class="Accordion Accordion--default fr-accordion js-fr-accordion" id="accordion-1">
			<div class="Grid Grid--withGutter u-padding-all-xs u-text-r-xxs u-margin-r-right">
					<div class="Grid-cell u-sizeFull u-md-size1of2 u-lg-size1of2 u-padding-bottom-xs">
			    		<h2 class="Accordion-header js-fr-accordion__header fr-accordion__header u-borderRadius-l u-border-all-xxs u-background-10" style="width:99%;" id="accordion-header-0">
			    			<span class="Accordion-link">Parametri</span>
			    		</h2>
						<div id="accordion-panel-0" class="Accordion-panel fr-accordion__panel js-fr-accordion__panel u-background-grey-10">
						    <?php echo get_FiltriParametri();?>
						</div>
					</div>
					<div class="Grid-cell u-sizeFull u-md-size1of2 u-lg-size1of2">
			    		<h2 class="Accordion-header js-fr-accordion__header fr-accordion__header u-borderRadius-l u-border-all-xxs u-background-10"  style="width:99%;" id="accordion-header-1">
			    			<span class="Accordion-link">Categorie</span>
			    		</h2>
						<div id="accordion-panel-1" class="Accordion-panel fr-accordion__panel js-fr-accordion__panel u-background-grey-10">
						    <?php echo get_FiltriCategorie();?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php				  
echo ' <div class="Visalbo">
<a name="dati"></a> ';
if (get_option('opt_AP_VisualizzaEnte')=='Si')
		echo '<'.$titEnte.' ><span  class="titoloEnte">'.stripslashes(get_option('opt_AP_Ente')).'</span></'.$titEnte.'>';
echo '<'.$titPagina.'>'.$TitoloAtti.'</'.$titPagina.'>';
$Nav="";
if ($TotAtti>$N_A_pp){
	    $Para='';
	    foreach ($_REQUEST as $k => $v){
			if ($k!="Pag" and $k!="vf")
				if ($Para=='')
					$Para.=$k.'='.$v;
				else
					$Para.='&amp;'.$k.'='.$v;
		}
		if ($Para=='')
			$Para="?Pag=";
		else
			$Para="?".$Para."&amp;Pag=";
		$Npag=(int)($TotAtti/$N_A_pp);
		if ($TotAtti%$N_A_pp>0){
			$Npag++;
		}
		$Nav.= '<nav role="navigation" aria-label="Navigazione paginata" class="u-layout-prose">
    <ul class="Grid Grid--fit Grid--alignMiddle">
		<li class="Grid-cell u-textCenter u-md-inlineBlock u-lg-inlineBlock">
			<strong>N. Atti '.$TotAtti.'</strong>
        </li>';
     	if (isset($_REQUEST['Pag']) And $_REQUEST['Pag']>1 ){
 			$Pagcur=$_REQUEST['Pag'];
			$PagPre=$Pagcur-1; 
				$Nav.= '<li class="Grid-cell u-textCenter u-md-inlineBlock u-lg-inlineBlock"><a href="'.$Para.'1" title="Vai alla prima pagina" class="u-color-50 u-textClean u-block u-md-inlineBlock u-lg-inlineBlock"><span class="fas fa-angle-double-left"></span></a></li>
					  <li class="Grid-cell u-textCenter u-md-inlineBlock u-lg-inlineBlock"><a href="'.$Para.$PagPre.'" title="Vai alla pagina precedente" class="u-color-50 u-textClean u-block u-md-inlineBlock u-lg-inlineBlock"><span class="fas fa-angle-left"></span></a></li> ';
		}else{
				$Nav.= '<li class="Grid-cell u-textCenter u-md-inlineBlock u-lg-inlineBlock"><span class="fas fa-angle-double-left u-color-grey-40  u-block u-md-inlineBlock u-lg-inlineBlock"></span></li>
					  <li class="Grid-cell u-textCenter u-md-inlineBlock u-lg-inlineBlock"><span class="fas fa-angle-left u-color-grey-40  u-block u-md-inlineBlock u-lg-inlineBlock"></span></a></li> ';			
			$Pagcur=1;
		}
		switch($Npag){
			case 1:
				$Inf=1;
				$Sup=1;
				break;
			case 2:
				$Inf=1;
				$Sup=2;
				break;
			default:
				if($Pagcur<$Npag){
					if($Pagcur<2){
						$Inf=1;
						$Sup=3;
					}else{
						$Inf=$Pagcur-1;
						$Sup=$Pagcur+1;
					}		
				}else{
						$Inf=$Npag-2;
						$Sup=$Npag;			
				}
				break;
		}
		for($i=$Inf;$i<$Sup+1;$i++){
			if($i==$Pagcur){
				$Nav.= "<li class=\"Grid-cell u-textCenter u-md-inlineBlock u-lg-inlineBlock\">
					<span class=\"u-padding-r-all u-block u-background-50 u-color-white\"><span class=\"u-text-r-s\">".$i."</span></li>";
			}else{
				$Nav.= "<li class=\"Grid-cell u-textCenter u-md-inlineBlock u-lg-inlineBlock\"><a href=\"".$Para.$i."\" class=\"u-color-50 u-textClean u-block u-md-inlineBlock u-lg-inlineBlock\">".$i."</a></li>";
			}
		}
   		if ($Npag>0 ){
   			$CurPage=(isset($_REQUEST['Pag'])?$_REQUEST['Pag']:1);
   			$PagSuc=($Pagcur==$Npag?$Npag:$Pagcur+1);
 			$Nav.= '<li class="Grid-cell u-textCenter u-md-inlineBlock u-lg-inlineBlock">';
 			if ($CurPage<$Npag)
 				$Nav.= '<a href="'.$Para.$PagSuc.'" title="Vai alla pagina successiva"><span class="fas fa-angle-right u-color-50 u-textClean u-block u-md-inlineBlock u-lg-inlineBlock"></span></a></li>';
 			else
 				$Nav.= '<span class="fas fa-angle-right u-color-grey-40 u-block u-md-inlineBlock u-lg-inlineBlock"></span></li>';
			$Nav.= '<li class="Grid-cell u-textCenter u-md-inlineBlock u-lg-inlineBlock">';
			if ($CurPage<$Npag) 
				$Nav.= '<a href="'.$Para.$Npag.'" title="Vai all\'ultima pagina"><span class="fas fa-angle-double-right u-color-50 u-textClean u-block u-md-inlineBlock u-lg-inlineBlock"></span></a></li>';
			else
				$Nav.= '<span class="fas fa-angle-double-right u-color-grey-40  u-block u-md-inlineBlock u-lg-inlineBlock"></span></li>';
		}
		$Nav.= '</ul>
		</nav>';
	}	
echo $Nav;
$FEColsOption=get_option('opt_AP_ColonneFE',array(
									"Data"=>0,
									"Ente"=>0,
									"Riferimento"=>0,
									"Oggetto"=>0,
									"Validita"=>0,
									"Categoria"=>0,
									"Note"=>0,
									"RespProc"=>0,
									"DataOblio"=>0));
if(!is_array($FEColsOption)){
	$FEColsOption=shortcode_atts(array(
				"Data"=>0,
				"Ente"=>0,
				"Riferimento"=>0,
				"Oggetto"=>0,
				"Validita"=>0,
				"Categoria"=>0,
				"Note"=>0,
				"RespProc"=>0,
				"DataOblio"=>0), json_decode($FEColsOption,TRUE),"");
}	
echo '	<div class="tabalbo">                               
		<table class="Table js-TableResponsive tablesaw tablesaw-stack" data-tablesaw-mode="stack" summary="atti validi per riferimento, oggetto e categoria"> 	
		<thead>
	    	<tr>
	        	<th scope="col">Prog.</th>';
foreach($FEColsOption as $Opzione => $Valore){
		if($Valore==1){
			echo '			<th scope="col">'.$Opzione.'</th>';
		}
}
echo '	</tr>
	    </thead>
	    <tbody>';
	    $CeAnnullato=false;
	if ($lista){
	 	$pari=true;
		if (strpos(get_permalink(),"?")>0)
			$sep="&amp;";
		else
			$sep="?";
		foreach($lista as $riga){
			$Link='<a href="'.get_permalink().$sep.'action=visatto&amp;id='.$riga->IdAtto.'"  style="text-decoration: underline;">';
			$categoria=ap_get_categoria($riga->IdCategoria);
			$cat=$categoria[0]->Nome;
			$NumeroAtto=ap_get_num_anno($riga->IdAtto);
	//		Bonifica_Url();
			$ParCella='';
			if($riga->DataAnnullamento!='0000-00-00'){
				$ParCella='style="background-color: '.$coloreAnnullati.';" title="Atto Annullato. Motivo Annullamento: '.$riga->MotivoAnnullamento.'"';
				$CeAnnullato=true;
			}
			echo '<tr >
			        <td '.$ParCella.'>'.$Link.$NumeroAtto.'/'.$riga->Anno .'</a> 
					</td>';
			if ($FEColsOption['Data']==1)
				echo '
					<td '.$ParCella.'>
						'.ap_VisualizzaData($riga->Data) .'
					</td>';
			if ($FEColsOption['Ente']==1)
				echo '
					<td '.$ParCella.'>
						'.stripslashes(ap_get_ente($riga->Ente)->Nome) .'
					</td>';
			if ($FEColsOption['Riferimento']==1)
				echo '
					<td '.$ParCella.'>
						'.stripslashes($riga->Riferimento) .'
					</td>';
			if ($FEColsOption['Oggetto']==1)
				echo '			
					<td '.$ParCella.'>
						'.stripslashes($riga->Oggetto) .'
					</td>';
			if ($FEColsOption['Validita']==1)
				echo '								
					<td '.$ParCella.'>
						'.ap_VisualizzaData($riga->DataInizio) .'<br />'.ap_VisualizzaData($riga->DataFine) .'  
					</td>';
			if ($FEColsOption['Categoria']==1)
				echo '								
					<td '.$ParCella.'>
						'.$cat .'
					</td>';
			if ($FEColsOption['Note']==1)
				echo '
					<td '.$ParCella.'>
						'.stripslashes($riga->Informazioni) .'
					</td>';
			if ($FEColsOption['RespProc']==1) {
				$responsabileprocedura=ap_get_responsabile($riga->RespProc);
				if (count($responsabileprocedura))
					$respproc=$responsabileprocedura[0]->Cognome." ".$responsabileprocedura[0]->Nome;
				else
					$respproc="";
				echo '
					<td '.$ParCella.'>
						'.$respproc .'
					</td>';				
			}
			if ($FEColsOption['DataOblio']==1)
				echo '
					<td '.$ParCella.'>
						'.ap_VisualizzaData($riga->DataOblio) .'
					</td>';
		echo '	
				</tr>'; 
			}
	} else {
			echo '<tr>
					<td colspan="6">Nessun Atto Codificato</td>
				  </tr>';
	}
	echo '
     </tbody>
    </table>';
echo '</div>';
	if ($CeAnnullato) 
		echo '<p>Le righe evidenziate con questo sfondo <span style="background-color: '.$coloreAnnullati.';">&nbsp;&nbsp;&nbsp;</span> indicano Atti Annullati</p>';
echo '</div><!-- /wrap -->	';
echo $Nav;
return ob_get_clean();
}
?>