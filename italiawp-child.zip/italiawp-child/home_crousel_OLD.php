
<div class="u-layout-wide u-layoutCenter u-layout-withGutter u-padding-r-top u-padding-bottom-xs" id="Link">
	<section id="Servizi">
  		<h2 class="u-text-h2 widget-title">Servizi</h2>
			<div class="col-xs-12">
				<div class="carousel slide" id="mioCarosello">
					<div class="carousel-inner">
						<div class="item active">
								<ul class="thumbnails" style="border:none;">
									<li class="col-sm-3">
										<div class="casing">
											<div class="thumbnail">
												<a href="#"><img src="http://placehold.it/360x240" alt=""></a>
											</div>
											<div class="caption">
												<h4>Item Title</h4>
												<p>Hello world, something nice to develop</p>
												<a class="btn btn-mini" href="#">� Read More</a>
											</div>
										</div>

									</li>
									<li class="col-sm-3">
										<div class="casing">
											<div class="thumbnail">
												<a href="#"><img src="http://placehold.it/360x240" alt=""></a>
											</div>
											<div class="caption">
												<h4>Item Title</h4>
												<p>Hello world, something nice to develop</p>
												<a class="btn btn-mini" href="#">� Read More</a>
											</div>
										</div>
									</li>
									<li class="col-sm-3">
										<div class="casing">
											<div class="thumbnail">
												<a href="#"><img src="http://placehold.it/360x240" alt=""></a>
											</div>
											<div class="caption">
												<h4>Item Title</h4>
												<p>Hello world, something nice to develop</p>
												<a class="btn btn-mini" href="#">� Read More</a>
											</div>
										</div>
									</li>
									<li class="col-sm-3">
										<div class="casing">
											<div class="thumbnail">
												<a href="#"><img src="http://placehold.it/360x240" alt=""></a>
											</div>
											<div class="caption">
												<h4>Item Title</h4>
												<p>Hello world, something nice to develop</p>
												<a class="btn btn-mini" href="#">� Read More</a>
											</div>
										</div>
									</li>
								</ul>
						  </div><!-- /Slide1 --> 
						<div class="item">
								<ul class="thumbnails">
									<li class="col-sm-3">
										<div class="casing">
											<div class="thumbnail">
												<a href="#"><img src="http://placehold.it/360x240" alt=""></a>
											</div>
											<div class="caption">
												<h4>Item Title</h4>
												<p>Hello world, something nice to develop</p>
												<a class="btn btn-mini" href="#">� Read More</a>
											</div>
										</div>
									</li>
									<li class="col-sm-3">
										<div class="casing">
											<div class="thumbnail">
												<a href="#"><img src="http://placehold.it/360x240" alt=""></a>
											</div>
											<div class="caption">
												<h4>Item Title</h4>
												<p>Hello world, something nice to develop</p>
												<a class="btn btn-mini" href="#">� Read More</a>
											</div>
										</div>
									</li>
									<li class="col-sm-3">
										<div class="casing">
											<div class="thumbnail">
												<a href="#"><img src="http://placehold.it/360x240" alt=""></a>
											</div>
											<div class="caption">
												<h4>Item Title</h4>
												<p>Hello world, something nice to develop</p>
												<a class="btn btn-mini" href="#">� Read More</a>
											</div>
										</div>
									</li>
									<li class="col-sm-3">
										<div class="casing">
											<div class="thumbnail">
												<a href="#"><img src="http://placehold.it/360x240" alt=""></a>
											</div>
											<div class="caption">
												<h4>Item Title</h4>
												<p>Hello world, something nice to develop</p>
												<a class="btn btn-mini" href="#">� Read More</a>
											</div>
										</div>
									</li>
								</ul>
						  </div><!-- /Slide2 --> 
						<div class="item">
								<ul class="thumbnails">
									<li class="col-sm-3">	
										Primo/3
									</li>
									<li class="col-sm-3">
										Secondo/3
									</li>
									<li class="col-sm-3">
										Terzo/3
									</li>
									<li class="col-sm-3">
										Quarto/3
									</li>
								</ul>
						  </div><!-- /Slide3 --> 
					</div>
				   <nav>
						<ul class="control-box pager">
							<li class="left">
								<a data-slide="prev" href="#mioCarosello" class="arrowStil"><i class="glyphicon glyphicon-chevron-left"></i></a>
							</li>
							<li class="right">
								<a data-slide="next" href="#mioCarosello" class="arrowStil"><i class="glyphicon glyphicon-chevron-right"></i></a>
							</li>
						</ul>
					</nav>
				</div><!-- /#mioCarosello -->
			</div>
  	</section>
</div>










